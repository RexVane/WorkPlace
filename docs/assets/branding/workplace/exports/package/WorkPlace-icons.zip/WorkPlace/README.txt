WorkPlace / Joinery
Selected by the user on 2026-10-09.

Default app icon: exports/windows/WorkPlace.ico
PNG: exports/dark/ and exports/light/
Small icons (16/20/24 px) use optically adjusted geometry.
Monochrome: exports/mono-dark/ and exports/mono-light/
SVG: icon.svg, icon-light.svg, symbol.svg, plus small variants.
Foreground and unmasked background are retained for platform adaptation.
This package contains artwork only; it does not install or rename the app.
